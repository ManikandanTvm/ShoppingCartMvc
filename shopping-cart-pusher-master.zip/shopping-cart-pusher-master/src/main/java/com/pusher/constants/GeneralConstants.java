package com.pusher.constants;

/**
 * General constants file *
 */
public interface GeneralConstants {
	/** ID in the session of the shopping cart object */
  String ID_SESSION_SHOPPING_CART = "shopping-cart-1";
}
