var Header = React.createClass({
  render: function() {
    return (
      <div className="row extra-bottom-margin">
        <div className="col-xs-12 text-center">
          <h1 className="white">Real-time shopping cart with Pusher, Java, and React</h1>
        </div>
      </div>
    );
  }
});